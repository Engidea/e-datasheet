================ Simplicity Studio ===========================================

This package contains Simplicity Studio.

Simplicity studio is a tool developed by Silicon Laboratories, Inc. to 
make it easy for developers to get access to the latest documentation, 
tools, software libraries, application notes and news.

================ Licenses ====================================================
Simplicity Studio is Copyright Silicon Laboratories, Inc., 2013.

DISCLAIMER OF WARRANTY/LIMITATION OF REMEDIES: Silicon Laboratories, Inc. 
has no obligation to support this Software. Silicon Laboratories, Inc. is 
providing the Software "AS IS", with no express or implied warranties of 
any kind, including, but not limited to, any implied warranties of 
merchantability or fitness for any particular purpose or warranties 
against infringement of any proprietary rights of a third party.

Silicon Laboratories, Inc. will not be liable for any consequential, 
incidental, or special damages, or any other relief, or for any claim by 
any third party, arising from your use of this Software.

Simplicity Studio uses a number of third party LGPL licensed libraries:

Qt     
       http://qt-project.org/
QuaZip
       http://quazip.sourceforge.net

Please see the file LGPL.txt for details.

According to the LGPL, you have the right to receive full source code for the
LGPL licensed libraries we use. Contact us to get access to the source code 
for these libraries, or alternatively, download them from their respective 
project pages.

In addition, Simplicity Studio uses Zlib, which is licensed under the Zlib
license:
       http://zlib.net

To contact us, please go to:

http://support.energymicro.com,

or send a letter to:

Silicon Labs Norway AS
P.O.Box 4633 Nydalen 
N-0405 Oslo
NORWAY 



